export class Player {
    constructor() {
        this.maximumHealth = 0;
        this.currentHealth = 0;
        this.damage = 0;
        this.startItem = "";
    }
}
//playervalues
let player = new Player;
player.maximumHealth = 10;
player.currentHealth = 10;
player.damage = 3;
player.startItem = "Ultrapotion";
export { player };
//# sourceMappingURL=Player.js.map